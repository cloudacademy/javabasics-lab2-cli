package trivera.core;

public class Airport {

	public void checkIn(Passenger passenger) {

		//CODE1:
		// Using the 'if' statement, check the frequent flyer miles of the passenger
		// When the Frequent Flyer mileage of the passenger is zero, print "New
		// Passenger", else print "Frequent Flyer"

		//CODE2:
		// Print out the passenger name and Frequent Flyer mileage

		//CODE3:		
		// Using the switch statement print out the Member Level
		// The member level is defined as 'int memberLevel' within the Passenger class
		// 1 = Bronze
		// 2= Silver
		// 3 = Gold

		//CODE4:
		//Print an empty line
	}
}
